<?php
declare(strict_types=1);
/*
 * تراپو — API سرور:  /api/?a=<کار>
 * هر درخواست تغییردهنده: فقط POST + Origin همین سایت + سربرگ X-CSRF نشست.
 */
// پوشه برنامه (lib، private، data، config.php) بیرون از وب: کنار پوشه وب، یا در «trapo_app» کنار آن (چیدمان cPanel با .cpanel.yml)
$trapoRoot = dirname(__DIR__, 2);
if (!is_file($trapoRoot . '/lib/bootstrap.php') && is_file($trapoRoot . '/trapo_app/lib/bootstrap.php')) $trapoRoot .= '/trapo_app';
require $trapoRoot . '/lib/bootstrap.php';
Http::securityHeaders();

$a = preg_replace('/[^a-z_]/', '', (string) ($_GET['a'] ?? ''));
$post = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$needPost = ['register', 'login', 'logout', 'password', 'redeem', 'progress_put', 'quote', 'order', 'spend', 'quest', 'profile', 'social_open', 'social_claim',
             'm_login', 'm_logout', 'm_paid', 'm_cancel', 'm_promo_add', 'm_promo_toggle', 'm_gift'];
if (in_array($a, $needPost, true) && !$post) Http::fail('method', 405);

/** وضعیت کامل حساب برای برنامه */
function mePayload(array $u, array $s): array
{
    return ['ok' => true, 'user' => ['name' => $u['name'], 'login' => $u['login'], 'dev' => $u['dev_id'], 'ref' => $u['ref_code'], 'since' => (int) $u['created_at']],
            'csrf' => $s['csrf'], 'codes' => License::codes((int) $u['id']), 'referral' => Shop::referral($u), 'wallet' => Hearts::state((int) $u['id']), 'rewards' => Rewards::state($u)];
}

try {
    switch ($a) {
        /* ---------- حساب ---------- */
        case 'register': {
            if (!Http::sameOrigin()) Http::fail('origin', 403);
            $b = Http::body();
            $s = Auth::register(Http::str($b, 'login', 120), (string) ($b['pass'] ?? ''), Http::str($b, 'name', 60), Http::str($b, 'ref', 20), Http::str($b, 'contact', 120));
            Http::json(mePayload(Auth::user(), $s));
        }
        case 'login': {
            if (!Http::sameOrigin()) Http::fail('origin', 403);
            $b = Http::body();
            $s = Auth::login(Http::str($b, 'login', 120), (string) ($b['pass'] ?? ''));
            Http::json(mePayload(Auth::user(), $s));
        }
        case 'logout': Auth::requireCsrf(); Auth::logout(); Http::json(['ok' => true]);
        case 'me': {
            $u = Auth::user(); $s = Auth::session();
            if (!$u || !$s) Http::json(['ok' => false, 'err' => 'auth']);
            Http::json(mePayload($u, $s));
        }
        case 'password': { Auth::requireCsrf(); $u = Auth::requireUser(); $b = Http::body(); Auth::changePassword($u, (string) ($b['old'] ?? ''), (string) ($b['new'] ?? '')); Http::json(['ok' => true]); }

        /* ---------- کد فعال‌سازی ---------- */
        case 'redeem': {
            Auth::requireCsrf(); $u = Auth::requireUser(); $b = Http::body();
            $raw = Http::str($b, 'code', 200);
            // کد قلب (TRH1): قلب، نامحدود یا اشتراک روزانه مستقیم به کیف قلب
            if (strpos(preg_replace('/[^0-9A-Z]/', '', strtoupper($raw)), 'TRH1') === 0) { Http::limit('redeem|' . $u['id'], 12, 3600); Http::json(['ok' => true, 'heart' => Hearts::redeemCode($u, $raw)]); }
            $g = License::redeem($u, $raw);
            Http::json(['ok' => true, 'grant' => $g, 'codes' => License::codes((int) $u['id'])]);
        }

        /* ---------- فایل‌های رمزنگاری‌شده برنامه ---------- */
        case 'asset': {
            $u = Auth::requireUser(); $s = Auth::session();
            Content::serve($u, $s, (string) ($_GET['f'] ?? ''));
        }

        /* ---------- پیشرفت ---------- */
        case 'progress': { $u = Auth::requireUser(); Http::json(['ok' => true, 'items' => Progress::get($u)]); }
        case 'progress_put': { Auth::requireCsrf(); $u = Auth::requireUser(); $b = Http::body(); Http::json(['ok' => true, 'saved' => Progress::put($u, (array) ($b['items'] ?? []))]); }

        /* ---------- کیف قلب ---------- */
        case 'wallet': { $u = Auth::requireUser(); Http::json(['ok' => true, 'wallet' => Hearts::state((int) $u['id']), 'rewards' => Rewards::state($u)]); }
        /* ---------- مأموریت روزانه و جایزه‌ها (قلب هدیه) ---------- */
        case 'quest': { Auth::requireCsrf(); $u = Auth::requireUser(); Http::limit('quest|' . $u['id'], 60, 3600); Http::json(['ok' => true, 'wallet' => Hearts::questClaim((int) $u['id'], Http::str(Http::body(), 'id', 20))]); }
        case 'profile': { Auth::requireCsrf(); $u = Auth::requireUser(); Http::limit('profile|' . $u['id'], 30, 3600); Http::json(['ok' => true] + Rewards::saveProfile($u, Http::body())); }
        case 'social_open': { Auth::requireCsrf(); $u = Auth::requireUser(); Rewards::socialOpen($u, Http::str(Http::body(), 'net', 20)); Http::json(['ok' => true]); }
        case 'social_claim': { Auth::requireCsrf(); $u = Auth::requireUser(); Http::limit('social|' . $u['id'], 30, 3600); Http::json(['ok' => true] + Rewards::socialClaim($u, Http::str(Http::body(), 'net', 20))); }
        case 'spend': {
            Auth::requireCsrf(); $u = Auth::requireUser(); Http::limit('spend|' . $u['id'], 1500, 3600); $b = Http::body();
            Http::json(['ok' => true, 'wallet' => Hearts::spend((int) $u['id'], (array) ($b['ev'] ?? []))]);
        }

        /* ---------- خرید، تخفیف و معرف ---------- */
        case 'quote': { Auth::requireCsrf(); $u = Auth::requireUser(); Http::json(['ok' => true] + Shop::quote($u, Http::body())); }
        case 'order': { Auth::requireCsrf(); $u = Auth::requireUser(); Http::json(['ok' => true] + Shop::createOrder($u, Http::body())); }
        case 'orders': { $u = Auth::requireUser(); Http::json(['ok' => true, 'orders' => Shop::myOrders($u)]); }
        case 'referral': { $u = Auth::requireUser(); Http::json(['ok' => true] + Shop::referral($u)); }

        /* ---------- پنل مدیریت سرور ---------- */
        case 'm_login': { if (!Http::sameOrigin()) Http::fail('origin', 403); $b = Http::body(); $s = Manage::login((string) ($b['pass'] ?? '')); Http::json(['ok' => true, 'csrf' => $s['csrf']]); }
        case 'm_me': { $s = Manage::require(); Http::json(['ok' => true, 'csrf' => $s['csrf']]); }
        case 'm_logout': { Auth::requireCsrf('admin'); Auth::logout('admin'); Http::json(['ok' => true]); }
        case 'm_stats': { Manage::require(); Http::json(['ok' => true] + Manage::stats()); }
        case 'm_orders': { Manage::require(); Http::json(['ok' => true, 'orders' => Manage::orders((string) ($_GET['status'] ?? 'pending'))]); }
        case 'm_users': { Manage::require(); Http::json(['ok' => true, 'users' => Manage::users((string) ($_GET['q'] ?? ''))]); }
        case 'm_users_csv': { Manage::require(); Manage::usersCsv(); }
        case 'm_trace': { Manage::require(); $f = Content::wmFind((string) ($_GET['tag'] ?? '')); Http::audit(null, 'm_trace', ['found' => (bool) $f]); Http::json(['ok' => true, 'user' => $f]); }
        case 'm_gift': { Manage::require(); Auth::requireCsrf('admin'); $b = Http::body(); Http::json(['ok' => true, 'wallet' => Hearts::gift((int) ($b['uid'] ?? 0), (int) ($b['hearts'] ?? 0), (int) ($b['ult_days'] ?? 0))]); }
        case 'm_promos': { Manage::require(); Http::json(['ok' => true, 'promos' => Manage::promos()]); }
        case 'm_paid': { Manage::require(); Auth::requireCsrf('admin'); $b = Http::body(); Http::json(['ok' => true] + Shop::markPaid(Http::str($b, 'order', 20), Http::str($b, 'note', 300))); }
        case 'm_cancel': { Manage::require(); Auth::requireCsrf('admin'); $b = Http::body(); Shop::cancel(Http::str($b, 'order', 20)); Http::json(['ok' => true]); }
        case 'm_promo_add': { Manage::require(); Auth::requireCsrf('admin'); Http::json(['ok' => true, 'promo' => Manage::promoAdd(Http::body())]); }
        case 'm_promo_toggle': { Manage::require(); Auth::requireCsrf('admin'); $b = Http::body(); Manage::promoToggle(Http::str($b, 'code', 24)); Http::json(['ok' => true]); }

        default: Http::fail('unknown', 404);
    }
} catch (RuntimeException $e) {
    // خطاهای قابل انتظار (موجودی ناکافی، سفارش نامعتبر …) بدون جزئیات فنی
    Http::fail(preg_match('/^[a-z_]{2,30}$/', $e->getMessage()) ? $e->getMessage() : 'failed', 400);
}
